#!/bin/bash
TITLE="--title SDK"

if [ -z "$1" ]; then
  TMPMENU=.tmpmenu
  whiptail $TITLE --menu "Action:" 16 30 8 \
      g "Generate" b "Build"    c "Clean"  t "Testing" \
      r "Results"  i "Install"  p "Print"  q "Quit" \
    2>$TMPMENU || { rm -rf $TMPMENU; exit 0; }
  test -e $TMPMENU || exit 0
  ACTION=`cat $TMPMENU`
  rm $TMPMENU
  RERUN=yes
else
  ACTION=$1
  RERUN=
  shift
fi

if [ -z "$1" ]; then
  case $ACTION in
    g|b|i|p)
      TMPMENU=.tmpmenu
      whiptail $TITLE --radiolist "Version:" 13 30 5 \
        Debug "" on Release "" off \
        2>$TMPMENU || { rm -rf $TMPMENU; exit 0; }
      test -e $TMPMENU || exit 0
      BUILD_MODE=`cat $TMPMENU`
      rm $TMPMENU ;;
  esac
else
  BUILD_MODE=${2:-Debug}
  shift
fi

[ "$BUILD_MODE" == "Debug" ] \
  && _OPTIONS=$DEBUG_BUILD_OPTIONS \
  || _OPTIONS=$RELEASE_BUILD_OPTIONS

generate() {
  mkdir -p "$BUILDDIR"
  pushd "$BUILDDIR"
    echo cmake .. -G "$CMAKEPLATFORM" $BUILD_OPTIONS $_OPTIONS \
        -DCMAKE_PREFIX_PATH=$CMAKEPREFIXPATH \
        -DCMAKE_INSTALL_PREFIX=$DISTRDIR \
        -DSDKDIR=$SDKDIR -DCMAKE_BUILD_TYPE=$BUILD_MODE
    sleep 2
    cmake .. -G "$CMAKEPLATFORM" $BUILD_OPTIONS $_OPTIONS \
        -DCMAKE_PREFIX_PATH=$CMAKEPREFIXPATH \
        -DCMAKE_INSTALL_PREFIX=$DISTRDIR \
        -DSDKDIR=$SDKDIR -DCMAKE_BUILD_TYPE=$BUILD_MODE \
        2>&1 | tee cmake_configure.log
  popd
}

build() {
  generate || exit 1
  pushd "$BUILDDIR"
    if [ "$CMAKEPLATFORM" == "Unix Makefiles" ]; then
      make VERBOSE=1 -j 5 2>&1 || exit 2
    else # Windows
      echo cmake --build . --config $BUILD_MODE --parallel
      sleep 2
      cmake --build . --config $BUILD_MODE 2>&1 | tee cmake_build.log && \
          echo "$PROJECTNAME successfully built and installed."
    fi
  popd
}

install() {
  [ ! -d "$BUILDDIR" ] && generate
  pushd "$BUILDDIR"
    if [ "$CMAKEPLATFORM" == "Unix Makefiles" ]; then
      make VERBOSE=1 -j 5 2>&1 || exit 1
      make install 2>&1 || exit 2
    else # Windows
      echo cmake --build . --config "$BUILD_MODE" --target install --parallel
      sleep 2
      cmake --build . --config "$BUILD_MODE" --target install --parallel 2>&1\
        | tee cmake_build.log && \
          echo "$PROJECTNAME successfully built and installed."
    fi
  popd
}

testing() {
  [ ! -d "$BUILDDIR" ] && build
  pushd "$BUILDDIR" && ctest && popd
}

results() {
  [ ! -d "$BUILDDIR" ] && testing
  pushd "$BUILDDIR" && cat Testing/Temporary/LastTest.log && popd
}

case $ACTION in
  p|print)
    echo -e "\nCMAKE_PREFIX_PATH:\n  $CMAKEPREFIXPATH"
    echo -e "BUILD_OPTIONS:  $BUILD_OPTIONS $_OPTIONS"
    echo -e "Build mode:  $BUILD_MODE\n"
    ;;
  g|generate) generate && echo "Project has been generated." || exit 1 ;;
  b|build)    build    && echo "Project has been built."     || exit 1 ;;
  i|install)  install  && echo "Project has been installed." || exit 1 ;;
  t|testing)  testing  && echo "Testing finished."           || exit 1 ;;
  r|results)  results || exit 1 ;;
  c|clean)
    [ -d "$BUILDDIR" ] && rm -rf "$BUILDDIR" && \
      echo "\`$BUILDDIR\` directory has been deleted."
    [ -d "$DISTRDIR" ] && rm -rf "$DISTRDIR" && \
      echo "\`$DISTRDIR\` directory has been deleted."
    ;;
  q|quit) RERUN="" ;;
esac

# Restart until `Quit` is chosen
[ -n "$RERUN" ] && echo "Press any key..." && read -r -N 1 -s && exec $0
