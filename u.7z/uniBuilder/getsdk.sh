#!/bin/bash
CN="\033[0m"
CR="\033[0;31m"
CG="\033[0;32m"
CM="\033[0;35m"
CC="\033[0;36m"

export WD=`echo "$ROOTDIR" | sed 's#\\\#/#g' | sed 's#/$##'`
export PROJECTNAME=`echo "$WD" | sed 's#.*/##'`
export BUILDDIR=$WD/BUILD
export DISTRDIR=$WD/DISTR
LOCALSDK=$WD/SDK
PATHS=

unpack_archive() {
  if [ -f "$1.zip" ] && [ "$CMAKEPLATFORM" != "Unix Makefiles" ]; then
    7z x "$1.zip"
  elif [ -f "$1.tar.gz"  ]; then tar xzf "$1.tar.gz"
  elif [ -f "$1.tar.bz2" ]; then tar xzf "$1.tar.bz2"
  elif [ -f "$1.tar.xz"  ]; then tar xzf "$1.tar.xz"
  elif [ -f "$1.zip"     ]; then unzip "$1.zip"
  else
    echo -e "\`$1.*\` archive ${CR}not found${CN}."
  fi
}

register_module() {
  if [ "$CMAKEPLATFORM" == "Unix Makefiles" ]; then
    [ -d "$1/bin" ] && export PATH="$1/bin":$PATH
    if [ -d "$1/lib" ]; then
      export LD_LIBRARY_PATH=$1/lib:$LD_LIBRARY_PATH
      if [ -d "$1/lib/pkgconfig" ]; then
        export PKG_CONFIG_PATH=$1/lib/pkgconfig:$PKG_CONFIG_PATH
      fi
    fi
  else # Windows
    [ -n "$2" ] && PATHS="$PATHS${PATHS:+;}$1" # for Tools
    [ -d "$1/bin" ] && PATHS="$PATHS${PATHS:+;}$1/bin"
    [ -d "$1/lib" ] && PATHS="$PATHS${PATHS:+;}$1/lib"
  fi
  CMAKEPREFIXPATH="$CMAKEPREFIXPATH${CMAKEPREFIXPATH:+;}$1"
}

import_module() {
  if [ -d "$1/$2" ]; then
    _ITEM=$1/$2
  else
    _ITEM=$LOCALSDK$3/$2
    if [ ! -d "$_ITEM" ]; then
      mkdir -p "$LOCALSDK$3" && pushd "$LOCALSDK$3"
        echo -e "Getting \`$2\`..." && unpack_archive "$1/$2"
      popd
    fi
  fi
  register_module "$_ITEM" "$3" # $3 not empty fot Tools
  echo -e "  * \`${CM}$2${CN}\` is ${CG}ready${CN} to use."
}

echo -e "Checking ${CM}SDK${CN}..."

TOOLSLOCALSUBDIR=/Tools
TOOLSLISTFILE=$TOOLSDIR/tools_list.txt
if [ -f "$TOOLSLISTFILE" ]; then
  TOOLSLIST=`sed -n "/^[^#]/p" "$TOOLSLISTFILE" | awk '{ print $2; }'`
  for I in $TOOLSLIST; do
    import_module "$TOOLSDIR" "$I" "$TOOLSLOCALSUBDIR"
  done
  echo -e "Tools in $LOCALSDK$TOOLSLOCALSUBDIR are ${CG}ready${CN} to use."
fi

SDKLIST=`grep "^[#:][#:] +" "$BASESCRIPT" | awk '{ print $3; }'`
for I in $SDKLIST; do
  import_module "${SDKROOTDIR:-$LOCALSDK}" "$I"
done

[ -z "$SDKROOTDIR" ] && mkdir -p "$LOCALSDK"
[ -d "$LOCALSDK" ] && SDKDIR=$LOCALSDK || SDKDIR=$SDKROOTDIR
echo -e "SDK in ${CC}$SDKDIR${CN} is ${CG}ready${CN} to use."

export SDKDIR
export CMAKEPREFIXPATH

VARSFILE=.vars.bat
if [ "$CMAKEPLATFORM" != "Unix Makefiles" ]; then # Windows
  { echo "set SDKDIR=$SDKDIR"
    echo "set PATH=$PATHS;%PATH%"
    echo "set CMAKEPREFIXPATH=$CMAKEPREFIXPATH"
    echo "set WD=$WD"
    echo "set PROJECTNAME=$PROJECTNAME"
    echo "set BUILDDIR=$BUILDDIR"
  } > $VARSFILE
fi
