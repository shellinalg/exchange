#ifndef REVIEWSREADER_H
#define REVIEWSREADER_H

#include "paper.h"

Papers ReadPapersReviews(const std::string& filename);

#endif  // REVIEWSREADER_H
