## Помянник (на английском языке)

Then offer a brief prayer for the health and salvation of thy spiritual father, thy parents, relatives, those in authority, benefactors, others known to thee, the ailing, or those passing through sorrows. And if it be possible, read this commemoration:

### For the Living:

Remember, O Lord Jesus Christ our God, Thy mercies and compassions which are from the ages, for the sake of which Thou didst become man and didst will to endure crucifixion and death for the salivation of those that rightly believe in Thee; 
and having risen from the dead didst ascend into the heavens and sittest at the right hand of God the Father, and regardest the humble entreaties of those that call upon Thee with all their heart; 
incline Thine ear, and hearken unto the humble supplication of me, Thine unprofitable servant, as an odor of spiritual fragrance, which I offer unto Thee for all Thy people. 

#### The Church

And first, remember Thy Holy, Catholic, and Apostolic Church, which Thou hast provided through Thy precious Blood, and establish, and strengthen, and expand, increase, pacify, and keep Her unconquerable by the gates of hades. calm the dissensions of the churches, quench the raging of the nations, and quickly destroy and uproot the rising of heresy, and bring them to nought by the power of Thy Holy Spirit. Bow.

#### The Russian Land, this land, and its authorities 

Save, O Lord, and have mercy on the Russian Land and her Orthodox people both in the homeland and in the diaspora, this land and its authorities. Bow.

#### The Clergy, and all the faithful 

Save, O Lord, and have mercy on the holy Eastern Orthodox patriarchs, most reverend metropolitans, Orthodox archbishops and bishops, and all the priestly and monastic order, and all who serve in the Church, whom Thou hast appointed to shepherd Thy rational flock, and through their prayers have mercy and save me, a sinner. Bow.

#### One's Spiritual father or confessor.

Save, O Lord, and have mercy on my spiritual father N., and through his holy prayers forgive my sins. Bow.

#### Parents, family and friends

Save, O Lord, and have mercy on my parents, Names, brothers and sisters, and my kindred according to the flesh, and all the neighbors of my family and friends, and grant them Thine earthly and spiritual good things. Bow.

#### Those in afflictions

Save, O Lord, and have mercy on the aged and the young, the poor and the orphans and widows, and those in sickness and sorrow, misfortune and tribulation, those in difficult circumstances and in captivity, in prisons and dungeons, and especially those of Thy servants that are persecuted for Thy sake and the Orthodox Faith by godless peoples, by apostates, and by heretics; and remember them, visit., strengthen, comfort, and by Thy power quickly grant them relief, freedom, and deliverance. Bow.

#### Enemies 

Save, O Lord, and have mercy on them that hate and wrong me, and make temptation for me, and let them not perish because of me, a sinner. Bow.

#### Apostates and all heretics 

Illumine with the light of awareness the apostates from the Orthodox Faith, and those blinded by pernicious heresies, and number them with Thy Holy, Apostolic, Catholic Church. Bow. 

### For the Departed:

#### Rulers, the Clergy and Monastics 

Remember, O Lord, those that have departed this life, Orthodox kings and queens, princes and princesses, most holy patriarchs, most reverend metropolitans, Orthodox archbishops and bishops, those in priestly and clerical orders of the Church, and those that have served Thee in the monastic order, and grant them rest with the saints in Thine eternal tabernacles. Bow.

#### Parents and friends 

Remember, O Lord, the souls of Thy departed servants, my parents, Names, and all my kindred according to the flesh, and forgive them all transgressions, voluntary and involuntary, granting them the kingdom and a portion of Thine eternal good things, and the delight of Thine endless and blessed life. Bow.

#### All other departed Orthodox Christians 

Remember, O Lord, also all our fathers and brethren, and sisters, and those that lie here, and all Orthodox Christians that departed in the hope of resurrection and life eternal, and settle them with Thy saints, where the light of Thy countenance shall visit them, and have mercy on us, for Thou art good and the Lover of mankind. Bow.

Grant, O Lord, remission of sins to all our fathers, brethren, and sisters that have departed before us in the faith and hope of resurrection, and make their memory to be eternal. Bow.
