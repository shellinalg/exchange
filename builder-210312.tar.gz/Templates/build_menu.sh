#!/bin/bash
# Build parameters
# ================
export BUILD_OPTIONS=""
export DEBUG_BUILD_OPTIONS=""
export RELEASE_BUILD_OPTIONS=""

## Linux SDK
## =========
## - openssl
## - cmake
## - boost

export ROOTDIR=$PWD
export BUILD_SCRIPTS_DIR=$HOME/workspace/uniBuilder
export BUILD_SCRIPTS_REP=
export TOOLSDIR=
export SDKROOTDIR=$BUILD_SCRIPTS_DIR/DISTR

# Set environment variables, copy SDK
source "$BUILD_SCRIPTS_DIR/common.sh"
source "$BUILD_SCRIPTS_DIR/menu.sh" $*
