#!/bin/bash
./configure --prefix="$1" --with-python=python3 \
  --with-proj="$1/../proj" --with-libtiff="$1/../libtiff" && \
  make -j 4 && make install # too much threads may overflow RAM
