#!/bin/bash
pushd CEGUI-BUILD
mkdir -p BUILD && pushd BUILD
  cmake $CMPLATF -DCMAKE_INSTALL_PREFIX="$1" \
    -DCMAKE_PREFIX_PATH="$CMAKEPREFIXPATH" .. || exit 1
  cmake --build . --config Release || exit 1
  mkdir "$1/include" "$1/lib"
  cp libcal3d.so "$1/lib"
  cp -r dependencies/include/cal3d $1/include
popd # BUILD
popd # CEGUI-BUILD
