#!/bin/bash
./bootstrap --prefix="$1" && make -j 4 && make install
