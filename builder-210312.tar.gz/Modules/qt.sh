#!/bin/bash
if [ "$CMAKEPLATFORM" != "Unix Makefiles" ]; then # Windows
  pushd "$SDKDIR"
    7z x ../Sources/postgresql-12.3-1-windows-x64-binaries.zip
  popd
fi

PATH=$PWD/qtbase/bin:$PWD/gnuwin32/bin:$PATH

#./configure.bat --help >> ../qt-configure-help.txt
#./configure.bat -list-libraries >> ../qt-libraries.txt

if [ "$CMAKEPLATFORM" != "Unix Makefiles" ]; then # Windows
  ./configure.bat -confirm-license -prefix "$1" \
    PSQL_PREFIX="$SDKDIR/pgsql" ZLIB_PREFIX="$SDKDIR/zlib-$ZLIB_VER" \
    -recheck-all -opensource -opengl desktop \
    -nomake examples -nomake tests -skip qtwebengine || exit 1

  #configure PSQL_PREFIX=F:/Users/Shmakov/Qt/pgsql -recheck-all -opensource
  #    -nomake examples -nomake tests -skip qtwebengine -opengl desktop
  #REM -sql-psql PSQL_PREFIX=F:\Users\Shmakov\Qt\pgsql
  #REM configure -opengl es2 -no-angle -debug -opengl desktop
  #              QT_ANGLE_PLATFORM=d3d9 -opengl dynamic

  # Serial build
  nmake || exit 1
  nmake install || exit 1
else
  ./configure -confirm-license -prefix "$1" \
    -recheck-all -opensource -opengl desktop \
    -nomake examples -nomake tests -skip qtwebengine || exit 1
  make -j 6 || exit 1 # Too much threads may overflow RAM
  make install
fi
