#!/bin/bash
./config --prefix="$1" && make -j && make install
