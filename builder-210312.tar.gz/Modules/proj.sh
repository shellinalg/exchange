#!/bin/bash
#mkdir -p BUILD && pushd BUILD
#  cmake $CMPLATF -DCMAKE_INSTALL_PREFIX="$1" \
#    -DBUILD_TESTING=OFF \
#    -DCMAKE_PREFIX_PATH="$CMAKEPREFIXPATH" .. || exit 1
#  cmake --build . --config Release --target install || exit 1
#popd # BUILD
./configure --prefix="$1" && make -j 4 && make install
