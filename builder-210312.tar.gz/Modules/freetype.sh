#!/bin/bash
./configure --prefix="$1" && make -j 4 && make install
exit 0
case $1 in
  url) echo \
    "https://download.savannah.gnu.org/releases/freetype/freetype-2.10.4.tar.gz"
    ;;
  *) ;;
esac
