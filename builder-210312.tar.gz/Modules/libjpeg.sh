#!/bin/bash
./configure --prefix="$1" && make -j && make install
