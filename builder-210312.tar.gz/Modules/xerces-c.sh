#!/bin/bash
chmod +x configure config/*
./configure --prefix="$1" && make -j 4 && make install
