#!/bin/bash
echo "Parameters: $2"
