#!/bin/bash
URL=https://gitlab.com/libeigen/eigen.git
DIR=`basename $URL .tar.gz`
case $1 in
  name) echo `basename $URL` ;;
  download) pushd "$SOURCES" && git clone $URL && popd ;;
  unzip) ;;
  build)
    ;;
  install)
    ;;
esac
