#!/bin/bash
URL=https://dl.bintray.com/boostorg/release/1.75.0/source/boost_1_75_0.tar.gz
DIR=`basename $URL .tar.gz`
case $1 in
  name) echo `basename $URL` ;;
  download) wget $URL ;;
  jllll
  unzip) tar xzf `basename $URL` ;;

  build)
    pushd "$DIR"
    SDK=`echo "$SDKDIR" | sed "s/\\\\\/\\//g"`
    ZLIB_VER=1.2.11
    ZLIB_SRC=../BUILD/zlib-$ZLIB_VER
    ZLIB_DIR=$SDK/zlib-$ZLIB_VER

    ./bootstrap$BAT --prefix="$SDK/zlib-$ZLIB_VER"
      # --without-python # --with-python=python3

    JAM=project-config.jam
    if [ -e $JAM ]; then
      if [ -z "`grep 'using mpi' $JAM`" ]; then
        { echo "using mpi ;"
          echo "using zlib : $ZLIB_VER"
          echo "   : <include>$ZLIB_DIR/include <search>$ZLIB_DIR/lib ;"
        } >> $JAM
      fi
    fi

    #./b2 --help zlib.init
    #./b2 --clean
    if [ "$CMAKEPLATFORM" != "Unix Makefiles" ]; then # Windows
      ./b2 --build-dir=build/x64 --stagedir=stage/x64 toolset=msvc \
        runtime-link=shared link=shared link=static address-model=64 release
      # debug release
      # -sZLIB_SOURCE=$ZLIB_SRC
    else # Linux
      ./b2 -sZLIB_SOURCE=$ZLIB_SRC
    fi
    popd # "$DIR"
    ;;

  install)
    pushd "$DIR"
    mkdir -p $SDKDIR/$DIR
    ./b2 install --prefix="$SDKDIR/$DIR"
    popd # "$DIR"
    ;;
esac
