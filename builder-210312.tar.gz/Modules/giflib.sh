#!/bin/bash
sed -i "s#^PREFIX = .*#PREFIX = $1#" Makefile && make && make install
