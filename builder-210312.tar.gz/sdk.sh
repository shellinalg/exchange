#!/bin/bash
ACTION=$1
PARAM=$2
shift && shift

export ROOTDIR=$PWD
export BUILD_SCRIPTS_DIR=.
export TOOLSDIR=
export SDKROOTDIR=$PWD/SDK
export OPENSSL_ROOT_DIR=$SDKDIR/openssl

# Set environment variables, copy SDK
source "$BUILD_SCRIPTS_DIR/common.sh"

BUILD_MODE=${PARAM:-Debug}
SOURCES=$PWD/Sources
MODVERSIONS=$PWD/Modules/versions.txt

active_sdk_items() {
  local MODS=`grep "^+" $MODVERSIONS | awk '{ print $2; }' | sort | uniq`
  for M in $MODS; do
    local S=`grep "^+ $M\>" $MODVERSIONS | head | awk '{ print $3; }'`
    local D=`grep "^+ $M\>" $MODVERSIONS | head | awk '{ print $4; }'`
    [ -z "$D" ] && basename $S || echo $D
  done
}

available_sdk_items() {
  sed -n '/^[+-]/p' $MODVERSIONS | awk '{ print $3; }' | sort | uniq
}

unpack_sources() {
  echo "Getting $1..."
  local Z=$SOURCES/$1
  if [ "$CMAKEPLATFORM" != "Unix Makefiles" ]; then # Windows
    if   [ -f "$Z.zip" ]; then 7z x "$Z.zip"
    elif [ -f "$Z.tar.gz" ]; then
      7z x "$Z.tar.gz" && 7z x *.tar && rm *.tar
    elif [ -f "$Z.tar.bz2" ]; then
      7z x "$Z.tar.bz2" && 7z x *.tar && rm *.tar
    elif [ -f "$Z.tar.xz" ]; then
      7z x "$Z.tar.xz" && 7z x *.tar && rm *.tar
    else hg clone "$1" || echo -e "\`$1\` sources ${CR}not found${CN}."
    fi
  else # Linux
    if   [ -f "$Z.tar.gz"  ]; then tar xzf "$Z.tar.gz"
    elif [ -f "$Z.tar.bz2" ]; then tar xjf "$Z.tar.bz2"
    elif [ -f "$Z.tar.xz"  ]; then tar xJf "$Z.tar.xz"
    elif [ -f "$Z.zip"     ]; then unzip "$Z.zip"
    else hg clone "$1" || echo -e "\`$1\` sources ${CR}not found${CN}."
    fi
  fi
}

make_with_cmake() {
  mkdir -p BUILD && pushd BUILD
    echo cmake .. -G "$CMAKEPLATFORM" -DCMAKE_INSTALL_PREFIX=$1 \
      -DCMAKE_PREFIX_PATH=$CMAKEPREFIXPATH
    cmake .. -G "$CMAKEPLATFORM" -DCMAKE_INSTALL_PREFIX=$1 \
      -DCMAKE_PREFIX_PATH=$CMAKEPREFIXPATH || exit 1
    cmake --build . --config Release --target install || exit 1
  popd # BUILD
}

make_module() {
  local M=$1
  echo '=================================================='
  echo "             BUILDING $M"
  echo '=================================================='
  local S=`grep "^+ $M\>" $MODVERSIONS | head | awk '{ print $3; }'`
  local D=`grep "^+ $M\>" $MODVERSIONS | head | awk '{ print $4; }'`
  [ -z "$D" ] && D=`basename $S`
  [ ! -d "$D" ] && unpack_sources $S
  mkdir -p $SDKDIR/$D
  pushd $D
    if [ -f ../../Modules/$M.sh ]; then
      source ../../Modules/$M.sh $SDKDIR/$D || exit 1
    elif [ -f CMakeLists.txt ]; then
      make_with_cmake $SDKDIR/$D
    elif [ -f configure ]; then
      ./configure --prefix=$SDKDIR/$D && \
      make -j 4 && make install
    elif [ -f autogen.sh ]; then
      ./autogen.sh && \
      ./configure --prefix=$SDKDIR/$D && \
      make -j 4 && make install
    else
      echo "ERROR: can not build \`$D\`."
    fi
  popd # $D
}

case $ACTION in
  item)
    M=$PARAM
    if [ -f Modules/$M.sh ]; then
      mkdir -p BUILD && pushd BUILD
        source ../Modules/$M.sh $* || exit 1
      popd # BUILD
    else
      echo -e "${CR}No such item${CN}: \`$M\`"
    fi
    ;;
  active) active_sdk_items ;;
  avail) available_sdk_items ;;
  p|print)
    echo -e "\nCMAKE_PREFIX_PATH:\n  $CMAKEPREFIXPATH"
    echo -e "BUILD_OPTIONS:\n  $BUILD_OPTIONS $_OPTIONS"
    echo -e "Build mode: $BUILD_MODE\n"
    ;;
  items) sed -e "s/^+/on/" -e "s/^-/off/" $MODVERSIONS \
          | awk '{ print $3, $2, $1; }' ;;
  build)
    mkdir -p BUILD && pushd BUILD
      MODS=`grep "^+" $MODVERSIONS | awk '{ print $2; }' | sort | uniq`
      for M in $MODS; do make_module $M; done
    popd # BUILD
    ;;
  clean)
    for I in `active_sdk_items`; do
      [ -d "SDK/$I" ] && { echo "Removing SDK/$I..."; rm -r SDK/$I; } \
        || echo "No \`SDK/$I\` found."
      [ -d "BUILD/$I" ] && { echo "Removing BUILD/$I..."; rm -r BUILD/$I; } \
        || echo "No \`BUILD/$I\` found."
    done ;;
  distr)
    echo "Zipping SDK modules to $PARAM/..."
    mkdir -p "$PARAM" || exit 1
    pushd SDK && for I in `active_sdk_items`; do
      echo "Zipping \`$I\`..."
      [ "$CMAKEPLATFORM" == "Unix Makefiles" ] \
        && tar czf ../$PARAM/${I}.tar.gz $I/ \
        || 7z  a   ../$PARAM/$I.zip $I/
    done; popd ;;
  choose)
    if [ -n "$PARAM" ]; then
      _TMPFILE=.versions.txt
      while read _STATUS _NAME _VERSION _DIRECTORY; do
        _STATUS=-
        [ "${PARAM/\"$_VERSION\"/}" != "$PARAM" ] && _STATUS=+
        echo $_STATUS $_NAME $_VERSION $_DIRECTORY
      done < $MODVERSIONS > $_TMPFILE && mv $_TMPFILE $MODVERSIONS
    fi ;;
  pack)
    echo "Zipping to \`$PARAM\`..."
    mkdir -p `dirname "$PARAM"`
    FILESLIST="Modules/ Templates/ getsdk.sh sdk sdk.* common.* menu.*"
    [ "$CMAKEPLATFORM" == "Unix Makefiles" ] \
      && tar czf $PARAM $FILESLIST \
      || 7z  a   $PARAM $FILESLIST
    ;;
esac
