#!/usr/bin/env python3
#-*- coding: utf-8 -*-

import os
import shutil
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.messagebox as msg
import threading
from time import sleep

class Window(ttk.Frame):

  def __init__(self, master=None):
    super().__init__(master)
    self.builddir = "BUILD"
    self.thread = False
    self.action = "{}/sdk.sh".format(os.environ["BUILD_SCRIPTS_DIR"])
    self.distrdir = "DISTR"
    self.buttons = []

    ttk.Label(self, text="{} menu".format(os.environ["PROJECTNAME"])
       ).pack(fill=tk.BOTH, expand=1, padx=40, pady=30)
    self.status = tk.StringVar()
    ttk.Label(self, textvariable=self.status).pack(fill=tk.BOTH, pady=10)

    self.buildmode = tk.StringVar()
    frame = tk.Frame(self)
    ttk.Radiobutton(frame, text="Release",
      variable=self.buildmode, value='Release').pack(side=tk.LEFT)
    ttk.Radiobutton(frame, text="Debug",
      variable=self.buildmode, value='Debug').pack(side=tk.LEFT)
    self.buttons.append(ttk.Button(frame, text="Build (b)",
      command=self.build))
    self.buttons[-1].pack(side=tk.LEFT, expand=1)
    frame.pack()
    self.bind_all('<KeyPress-b>', self.build)
    self.buildmode.set("Release")

    self.buttons.append(ttk.Button(self, text="Clean building (c)",
      command=self.clean))
    self.buttons[-1].pack(fill=tk.X)
    self.bind_all('<KeyPress-c>', self.clean)

    self.buttons.append(ttk.Button(self, text="Distribute (d)",
      command=self.distr))
    self.buttons[-1].pack(fill=tk.X)
    self.bind_all('<KeyPress-d>', self.distr)

    self.buttons.append(ttk.Button(self, text="Pack (p)",
      command=self.package))
    self.buttons[-1].pack(fill=tk.X)
    self.bind_all('<KeyPress-p>', self.package)

    self.buttons.append(ttk.Button(self, text="Quit (q)", command=self.exit))
    self.buttons[-1].pack(fill=tk.X)
    self.bind_all('<KeyPress-q>', self.exit)

    self.pack()

  def startProcessing(self, msg, f):
    self.thread = threading.Thread(target=f)
    self.thread.daemon = True
    self.thread.start()
    self.status.set(msg)
    for b in self.buttons:
      b.config(state='disabled')

  def finishProcessing(self, msg):
    for b in self.buttons:
      b.config(state='enabled')
    self.status.set(msg)

  def build(self, event=None):
    self.startProcessing("Building...", self.processBuild)

  def processBuild(self):
    os.system("bash {} build {}".format(self.action, self.buildmode.get()))
    self.finishProcessing("Building finished.")

  def clean(self, event=None):
    if msg.askquestion("Clean all?",
        "Delete BUILD and DISTR directories?") == "yes":
      self.startProcessing("Cleaning...", self.processClean)

  def processClean(self):
    os.system("bash {} clean".format(self.action))
    self.finishProcessing("Cleaning finished.")

  def distr(self, event=None):
    self.startProcessing("Distributing...", self.processDistr)

  def processDistr(self):
    os.system("bash {} distr {}".format(self.action, self.distrdir))
    self.finishProcessing("SDK modules have been distributed to DISTR/.")

  def package(self, event=None):
    self.startProcessing("Packing...", self.processPackage)

  def processPackage(self):
    packname = "DISTR/backup.zip"
    os.system("bash {} pack {}".format(self.action, packname))
    self.finishProcessing(
          "uniBuilder have been packed to {}.".format(packname))

  def exit(self, event=None):
    self.quit()


window = Window()
window.master.title(os.environ["PROJECTNAME"])
window.master.mainloop()
