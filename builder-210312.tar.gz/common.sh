#!/bin/bash
export CMAKEPLATFORM="Unix Makefiles"
export BAT=.sh
export CMAKEPREFIXPATH=
export BASESCRIPT=build_menu.sh
source "$BUILD_SCRIPTS_DIR/getsdk.sh"
