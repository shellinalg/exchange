### Православие
* [Подстрочный перевод Ветхого и Нового Заветов](http://www.bible.in.ua/underl/index.htm)
* [Православная библиотека Церковь ру: православная литература, статьи, журналы](http://lib.cerkov.ru/)
* [Прервинская семинария](http://www.ppds.ru/library-seminarii/electronic-editions.html)
* [Святоотеческая библиотека.](http://pravlib.ru/books.html)
* [Святоотеческая библиотека.](http://otechnik.narod.ru/books.html)
* [Славянские рукописи.](http://www.stsl.ru/manuscripts/index.php)
* [Словесная служба. Страница священника Михаила Желтова](http://www.mhzh.ru/)
* [Супер Книга - Навигатор (On-line Библия + Симфония + Толковые словари)](http://www.superbook.org/index_ru.htm)
* [Электронная библиотека. Раздел: «Литургика» : Московская православная духовная академия](http://www.mpda.ru/publ/rubric/32241.html)
* [Biblezoom - Углубленное исследование библейского текста. Пасторам церквей, преподавателям и студентам духовных учебных заведений рекомендуется.](http://www.biblezoom.ru/)
* [Православный Церковный календарь](http://days.pravoslavie.ru/)
* [Slavonic Computing](http://sci.ponomar.net/)
* [Church Slavonic : For Users](http://sci.ponomar.net/users.html)
* [Библиотека святоотеческой литературы](http://www.orthlib.ru/)
* [Богослужебные тексты (seminaria.ru)](http://www.seminaria.ru/divservice/texts.htm)
* [Богослужение в русском переводе](http://azbyka.ru/bogosluzhenie/)
* [В последний путь. Православное поминовение усопших.](http://www.lw.bogoslovy.ru/)
* [Вертоград](http://wertograd.org/)
* [Книги на церковнославянском языке - Православная электронная библиотека читать скачать бесплатно](http://lib.pravmir.ru/library/cat/2100)
* [Богослужебные указания за 16 октября 2014 года: Сщмч. Дионисия Ареопагита, еп. Афинского. / Патриархия.ru](http://www.patriarchia.ru/bu/today)
* [ΕΛΛΗΝΙΚΑ ΛΕΙΤΟΥΡΓΙΚΑ ΚΕΙΜΕΝΑ, Μηναίον, Οκτώηχος, Τριώδιον, Πεντηκοστάριον](http://glt.goarch.org/)
* [Russian Orthodox-Christian services from: Horologion,Trebnic,Menaion: full texts, excerpts,cards](http://www.orthodox.net/services/index.html)
* [Orthodox Prayer Book](http://www.myriobiblos.gr/texts/english/prayerbook/main.htm)
* [Orthodox Liturgical Texts and Resources](http://www.saintjonah.org/services/)
* [Тропари, Полный Православный Тропарион для клироса и мирян с приложением некоторых кондаков](http://troparion.narod.ru/)
* [ТИПИКОН. Богослужение Православной Церкви ❘ Главная](http://typikon.ru/)
* [Алексей Ильич Осипов](http://alexey-osipov.ru/)
* [Алексей Ильич Осипов - YouTube](http://www.youtube.com/user/osipovalexeyilich/videos)
* [Богослужебные указания на завтра](http://www.patriarchia.ru/bu/tomorrow)
* [Официальный сайт РПЦ / Патриархия.ru](http://www.patriarchia.ru/index.html)
* [ПЕРЕРВИНСКАЯ ДУХОВНАЯ СЕМИНАРИЯ](http://www.ppds.ru/)
* [Православие.Ru / Pravoslavie.Ru](http://www.pravoslavie.ru/)
* [Православные просветительские курсы / Православие.Ru](http://www.pravoslavie.ru/74480.html#y2h1)
* [Курс: Основы Православия](http://distant.kursmpda.ru/course/view.php?id=6)
* [Index of /Книги за Православието на руски/Энциклопедии и справочники](http://www.megimg.info:4000/%d0%9a%d0%bd%d0%b8%d0%b3%d0%b8%20%d0%b7%d0%b0%20%d0%9f%d1%80%d0%b0%d0%b2%d0%be%d1%81%d0%bb%d0%b0%d0%b2%d0%b8%d0%b5%d1%82%d0%be%20%d0%bd%d0%b0%20%d1%80%d1%83%d1%81%d0%ba%d0%b8/%d0%ad%d0%bd%d1%86%d0%b8%d0%ba%d0%bb%d0%be%d0%bf%d0%b5%d0%b4%d0%b8%d0%b8%20%d0%b8%20%d1%81%d0%bf%d1%80%d0%b0%d0%b2%d0%be%d1%87%d0%bd%d0%b8%d0%ba%d0%b8/)
* [Новости сайта](https://azbyka.ru/bogosluzhenie/news.shtml)
* [10 ноября 2017 - Православный Церковный календарь](https://azbyka.ru/days/)
* [Виктор Лега / Авторы сайта Православие.Ru](http://www.pravoslavie.ru/authors/357.htm)


### Регистрации
* [RP5.RU: Расписание Погоды в Дивеево, Дивеевский район, Нижегородская область](http://rp5.ru/2866/ru)
* [Диакон.ру - всё о церковном служении диаконов](http://www.deacon.ru/)
* [Портал Богослов.Ru](http://www.bogoslov.ru/)

  E-mail      | Пароль       | Дополнительно
  ----------- | ------------ | -------------
  bogoslov.ru | `4i80xzf0f3` | Евгений

* [Dashboard ❘ MuseScore](https://musescore.com/dashboard)

  E-mail              | Регистрационное имя (Login) | Пароль
  ------------------- | --------------------------- | ----------
  shel.test@yandex.ru | shellv                      | !q2w3e3w2q1

* [Саровская пустынь :: Главная](http://www.sarov-monastery.org/)

### Библиотеки
* [10 ноября 2017 - Православный Церковный календарь](https://azbyka.ru/days/)
* [Библиотека православного христианина.](http://www.wco.ru/biblio/)
* [Библиотека русских переводов богослужебных текстов](http://www.churchlibrary.narod.ru/)
* [Библиотека святоотеческой литературы](http://www.orthlib.ru/)
* [Библиотечка православной литературы для КПК](http://www.ccel.org/contrib/ru/xml/#content)
* [Богослужебные тексты (seminaria.ru)](http://www.seminaria.ru/divservice/texts.htm)
* [Новости сайта](https://azbyka.ru/bogosluzhenie/news.shtml)
* [В последний путь. Православное поминовение усопших.](http://www.lw.bogoslovy.ru/)
* [Вертоград](http://wertograd.org/)
* [Книги на церковнославянском языке - Православная электронная библиотека читать скачать бесплатно](http://lib.pravmir.ru/library/cat/2100)
* [Православная библиотека Церковь ру: православная литература, статьи, журналы](http://lib.cerkov.ru/)
* [Православная медиатека Предание.ру ❘ Предание.Ру — крупнейшая православная медиатека рунета](http://predanie.ru/media/)
* [Православная электронная библиотека читать скачать бесплатно](http://lib.pravmir.ru/)
* [Православный народ](http://pravoslavnyi.narod.ru/)
* [Святоотеческая библиотека.](http://otechnik.narod.ru/books.html)
* [Святоотеческая библиотека.](http://pravlib.ru/books.html)
* [Святоотеческое наследие - Заглавная](http://tvorenia.russportal.ru/)
* [Славянские рукописи.](http://www.stsl.ru/manuscripts/index.php)
* [Словесная служба. Страница священника Михаила Желтова](http://www.mhzh.ru/)
* [ТИПИКОН. Богослужение Православной Церкви ❘ Главная](http://typikon.ru/)
* [Тропари, Полный Православный Тропарион для клироса и мирян с приложением некоторых кондаков](http://troparion.narod.ru/)
* [Электронная библиотека. Раздел: «Литургика» : Московская православная духовная академия](http://www.mpda.ru/publ/rubric/32241.html)
* [Электронные библейские и богословские книги / Тематический каталог / Кафедра библеистики МДА](https://www.bible-mda.ru/old/e-books/e-books.html)


### Текущее
* [GitHub - shellinalg/exchange](https://github.com/shellinalg/exchange)
* [Виктор Лега / Авторы сайта Православие.Ru](http://www.pravoslavie.ru/authors/357.htm)

### Образование
* [Философия / Облако Mail.Ru](https://cloud.mail.ru/public/M4xa/Xu9qj5VPZ/%D0%9C%D0%A4%D0%A2%D0%98/%D0%A4%D0%B8%D0%BB%D0%BE%D1%81%D0%BE%D1%84%D0%B8%D1%8F/)


### Текущее изучение
* [Atom](https://flight-manual.atom.io/)


### Типография

### Статья в Elsevier
* [LaTeX Templates » Academic Journals](http://www.latextemplates.com/cat/academic-journals)
* [LaTeX Templates » Elsevier’s elsarticle Document Class](http://www.latextemplates.com/template/elseviers-elsarticle-document-class)
* [GitHub - dmafanasyev/elsevier_latex_template: Common template of the research article using elsarticle class. It also contains elsarticle-ru class file and elsarticle-harv-ru bibliography style file that is russian translation of the originaly provided files by Elsevier (see http://www.elsevier.com/author-schemas/latex-instructions).](https://github.com/dmafanasyev/elsevier_latex_template)
* [Latex Instructions](https://www.elsevier.com/authors/author-schemas/latex-instructions)

* [Journals - ShareLaTeX, Online LaTeX Editor](https://www.sharelatex.com/templates/journals?nocdn=true)
* [Linguee ❘ Русско-английский словарь](https://www.linguee.ru/%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9-%D0%B0%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9/search?source=auto)
* [Google Переводчик](https://translate.google.com/)
* [Яндекс.Переводчик – словарь и онлайн перевод на английский, русский, немецкий, французский, украинский и другие языки.](https://translate.yandex.ru/?utm_source=wizard&lang=ru-en)
* [tuxtrans: Applications](https://www.uibk.ac.at/tuxtrans/software.html)
* [В помощь переводчику: 10 советов по OmegaT ❘ Заметки Белого Тигра](https://blog.wtigga.com/omegat/)
* [Resources - OmegaT](http://omegat.org/en/resources.html)
* [Run LilyPond in your browser without any software installation. - weblily.net](https://www.weblily.net/)


### Услуги
* [Главная :: Православный торрент-трекер](http://pravtor.spb.ru/index.php)
* [Просмотр профиля eeevg :: NNM-Club](http://nnm-club.me/forum/profile.php?mode=viewprofile&u=1531815&sid=c711bdbdae6332e718ea26b706447940#torrent)
* [Стартовая страница ❘ REG.RU](https://www.reg.ru/user/welcomepage)

* [МТС Банк ❘ Удобный интернет-банк](https://personalbank.ru/v1/cgi/bsi.dll?T=RT_2Auth.BF)
* [Сбербанк Онлайн](https://node2.online.sberbank.ru/PhizIC/private/accounts.do)
* [МТС - Личный кабинет](https://ihelper.nnov.mts.ru/selfcare/welcome.aspx)
* [Мой МТС - Личный кабинет](https://lk.mts.ru/)
* [Отслеживание](https://www.pochta.ru/tracking)
* [Лента операций](https://www.tinkoff.ru/events/feed/?auth=)
* [Портал государственных услуг Российской Федерации](https://www.gosuslugi.ru/)
* [Мобильный Билайн: мобильная связь и безлимитный интернет от ведущего сотового оператора - Нижний Новгород](https://nizhniy-novgorod.beeline.ru/customers/products/mobile/profile/#/home)
* [Яндекс.Облако](https://console.cloud.yandex.ru/)


### Design
* [Free vector icons - SVG, PSD, PNG, EPS &amp; Icon Font - Thousands of free icons](https://www.flaticon.com/)
* [Google Fonts](https://fonts.google.com/)
* [Octicons](https://octicons.github.com/)


### Education

* [W3Schools Online Web Tutorials](https://www.w3schools.com/default.asp)
* [Learn JavaScript, Front-End Web Development and Node.js with Frontend Masters Courses](https://frontendmasters.com/courses/)
* [Онлайн-курсы по веб-разработке: создавайте и совершенствуйте веб-сайты ❘ Udemy](https://www.udemy.com/courses/development/web-development/)
* [Web Standards Days](https://wsd.events/)


### HTML/CSS
* [Color Picker — HTML Color Codes](https://htmlcolorcodes.com/color-picker/)
* [HTML Color Picker](https://www.w3schools.com/colors/colors_picker.asp)
* [Index of CSS properties](https://www.w3.org/Style/CSS/all-properties.html)
* [3-9: Styling common HTML tags with CSS – Bioinformatics Web Development](http://www.cellbiol.com/bioinformatics_web_development/chapter-3-your-first-web-page-learning-html-and-css/styling-common-html-tags-with-css/)
* [CSS Color Scheme Generator](https://www.quackit.com/css/color/tools/css_color_scheme_generator.cfm)
* [Ultimate CSS Gradient Generator - ColorZilla.com](http://www.colorzilla.com/gradient-editor/)
* [Practical HTML and CSS [Video] [2018, ENG] :: RuTracker.org](https://rutracker.org/forum/viewtopic.php?t=5603062)
* [[Pluralsight.com] Play by Play: HTML, CSS, and JavaScript with Lea Verou [2014, ENG] :: RuTracker.org](https://rutracker.org/forum/viewtopic.php?t=5038698)


### Instruments

### Atom
* [Documentation](https://atom.io/docs)
* [file-type-icons](https://atom.io/packages/file-type-icons)
* [atom-html-preview](https://atom.io/packages/atom-html-preview)

* [Eclipse Installer](https://www.eclipse.org/downloads/packages/installer)
* [Avocode](https://avocode.com/)
* [Edit fiddle - JSFiddle](http://jsfiddle.net/ASmarterWayToLearn/bw9xo3do/)
* [webpack](https://webpack.js.org/)
* [Parcel](https://parceljs.org/)
* [Electron](https://electronjs.org/)
* [Kore - An easy to use web platform for C and Python](https://kore.io/)


### JavaScript
* [Современный учебник Javascript](http://learn.javascript.ru/)
* [Знакомство с CoffeeScript / Хабр](https://habr.com/post/179031/)
* [janl/mustache.js: Minimal templating with {{mustaches}} in JavaScript](https://github.com/janl/mustache.js)


### Net tools
* [Отладчик перепостов - Facebook for Developers](https://developers.facebook.com/tools/debug/sharing/)
* [Getting started with cards — Twitter Developers](https://developer.twitter.com/en/docs/tweets/optimize-with-cards/guides/getting-started)
* [The Open Graph protocol](http://ogp.me/)
* [Can I use... Support tables for HTML5, CSS3, etc](https://caniuse.com/#feat=maxlength)


### Frameworks
* [Начало работы с Font Awesome](http://fontawesome.ru/get-started/)
* [evilstreak/markdown-js: A Markdown parser for javascript](https://github.com/evilstreak/markdown-js)
* [jQuery API Documentation](http://api.jquery.com/)
* [Bootstrap](https://getbootstrap.com/docs/4.1/getting-started/introduction/)
* [Jasny Bootstrap](http://www.jasny.net/bootstrap/getting-started/)
* [TACHYONS - Css Toolkit](http://tachyons.io/#getting-started)
* [Semantic UI](https://semantic-ui.com/introduction/getting-started.html)
* [Foundation](https://foundation.zurb.com/sites/docs/)

### Reference
* [Все иконки Font Awesome](http://fontawesome.ru/all-icons/)
* [✔ - Жирная отметка галочкой (U+2714) символ, знак, значок, иконка, html: &amp;#10004; - Дингбаты - Таблица символов Юникода®](https://unicode-table.com/ru/2714/)
* [Forms · Bootstrap](https://getbootstrap.com/docs/4.1/components/forms/)
* [HTML 5.2](https://www.w3.org/TR/html/)
* [CSS Snapshot 2018](https://www.w3.org/TR/css/)
* [HTML elements reference ❘ MDN](https://developer.mozilla.org/en-US/docs/Web/HTML/Element)
* [Pseudo-classes and pseudo-elements ❘ MDN](https://developer.mozilla.org/en-US/docs/Learn/CSS/Introduction_to_CSS/Pseudo-classes_and_pseudo-elements)

